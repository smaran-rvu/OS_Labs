#!/bin/bash

echo "Hello, what is your name?"
read name
echo "Hi $name, how do you do?"
read reply
echo "Happy to know, I am also $reply  !!"
